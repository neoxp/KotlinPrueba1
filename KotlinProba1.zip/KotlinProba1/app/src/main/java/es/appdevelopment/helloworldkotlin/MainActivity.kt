/*

Creadp por Emili Marques
Derechos de autor.
Visitademe en wwww.appdevelopment.es
 */

package es.appdevelopment.helloworldkotlin

import android.os.Bundle
import android.widget.RatingBar
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), RatingBar.OnRatingBarChangeListener {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        //Por otra parte el calendario cambia solo de dia sin ningun problema.


        //Aui va el rankig de la app de prueba.
        ratingBar3.onRatingBarChangeListener = this

    }


    override fun onRatingChanged(p0: RatingBar?, p1: Float, p2: Boolean) {

        //Que cambia el texto al mover las flechas de numero.
        textView2.text = "$p1"

    }
}




